package Main;

import View.Mahasiswa.ViewData;

public class Main {

    public static void main(String[] args) {
        new ViewData();
    }
    
}
